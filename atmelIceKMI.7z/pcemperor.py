import subprocess

print '*********************************************************'
print 'Python script calling windows batches for calibration and'
print 'programming of Atmel AVR ATMega644pa trough ISP interface'
print 'with ATMELICE'
print '*********************************************************'

print '---------------------------------------------------------'
print ''
print '       ** S T A R T   P R O G R A M M I N G **'
print ''
print '---------------------------------------------------------'

calib = subprocess.Popen("atprogram_emperor_osc.bat", shell=False)
calib.wait()

calibrationValueFile = "oschex.hex"

with open(calibrationValueFile) as calibValHex:
    calibrationValue = calibValHex.read()

print 'calibrationValue = ' + calibrationValue

temporaryFirmware = "EmperorDeneme.hex"  # file should be in x folder

with open(temporaryFirmware, 'r+b') as firmwareFile:
    # """ Hex File Read Operation """
    firmwareFile.read()  # hex file to memory
    firmwareFile.seek(int(firmwareFile.tell()) - 27)  # move to file position :01FFFE00EA18
    firmwareFile.write(':01FFFE00'+calibrationValue+'00')
    #firmwareFile.write(':AAAAAAAA' + calibrationValue + '00')

with open(temporaryFirmware, 'r+b') as firmwareFile:
    firmwareFile.read()  # hex file to memory
    firmwareFile.seek(int(firmwareFile.tell()) - 26)  # move to file position 01FFFE00EA18
    calibrationLine = firmwareFile.readline(12)  # read the line with calibration byte
    print 'calibrationLine = ' + calibrationLine
    decodedCalibrationLine = calibrationLine.decode("hex")  # decode string to hex string
    #print 'decodedCalibrationLine = ' + decodedCalibrationLine
    integerChecksum = 0  # initial checksum value (integer)
    for i in range(0, len(decodedCalibrationLine) - 1):
        # """ summation loop of decoded string of line """
        integerChecksum += int(decodedCalibrationLine[i].encode("hex"), 16)
        #print decodedCalibrationLine[i]
    print 'summation = ' + str(integerChecksum)
    hexChecksum = hex(256 - integerChecksum + (integerChecksum / 256) * 256).split('x')[1]
    print 'hexadecimal checksum value for intelhex = ' + hexChecksum
    firmwareFile.seek(int(firmwareFile.tell()) - 2)  # move to file position 18
    firmwareFile.write(hexChecksum)

prog = subprocess.Popen("atprogram_emperor_prog.bat", shell=False)
prog.wait()